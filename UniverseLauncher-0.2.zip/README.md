# Universe Launcher 0.2 (integration prototype)

This project integrates the SolarCrystal 0.1 native C++ library and JNI bridge into the existing Android launcher app.

## What's integrated
- SolarCrystal C++ core compiled as `libsolarcrystal.so` through Android CMake/NDK.
- JNI bridge exposed through `com.universe.solarcrystal.NativeBridge`.
- Launcher UI branded as Universe Launcher.
- Startup status displays SolarCrystal version/status and a JNI arithmetic smoke test.

## Important limitation
This is an integration prototype, not a Minecraft Java runtime. It does not yet include a compatible desktop JVM, Minecraft libraries/assets, graphics backend, or game launch pipeline.

## Build
From this directory, with Android SDK, NDK and CMake installed:
`gradle assembleDebug`

GitHub Actions workflow: `.github/workflows/build-universe.yml`

## Build notes (0.2 build-fix)
- Gradle 8.10.2 + Android Gradle Plugin 8.7.3, Java 17, NDK 26.1.10909125, CMake 3.22.1, ABIs: arm64-v8a, armeabi-v7a, x86, x86_64.
- Only the `terra-android` module is built: `gradle :terra-android:assembleDebug`
- APK output: `terra-android/build/outputs/apk/debug/`
- The workflow installs SDK/NDK/CMake itself; no Gradle wrapper is included (the workflow provisions Gradle).

## Build fix (0.2-FIXED)

### Root cause of "ninja: error: manifest 'build.ninja' still dirty after 100 tries"

The error occurs when Ninja detects that the inputs of the CMake generation step (CMakeLists.txt and the C++ sources) have a modification time newer than the generated `build.ninja`. In this case the source files inside the provided ZIP had timestamps approximately 5 hours in the future relative to the CI runner clock.

Because the inputs always appear newer, Ninja re-runs CMake, which rewrites `build.ninja`, which is again considered dirty, and the loop continues until the hard limit of 100 retries.

This is a well-known interaction between CMake's Ninja generator and files with future mtimes (often introduced by ZIP archives created on a machine with a skewed clock, or by tools that preserve original timestamps).

### Fix applied

1. All project files in this archive have had their timestamps normalized to the time the archive was created.
2. The GitHub Actions workflow now contains an explicit step that runs `find ... -exec touch {} +` after the project is located (and after any ZIP is extracted). This makes the build robust even if future timestamps reappear.

No changes were required to the CMakeLists.txt logic, the JNI bindings, or the Gradle configuration. The SolarCrystal sources and the launcher UI remain unchanged.
