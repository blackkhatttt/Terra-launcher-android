# Universe Launcher 0.2 (integration prototype)

This project integrates the SolarCrystal 0.1 native C++ library and JNI bridge into the existing Android launcher app.

## What's integrated
- SolarCrystal C++ core compiled as `libsolarcrystal.so` through Android CMake/NDK.
- JNI bridge exposed through `com.universe.solarcrystal.NativeBridge`.
- Launcher UI branded as Universe Launcher.
- Startup status displays SolarCrystal version/status and a JNI arithmetic smoke test.

## Important limitation
This is an integration prototype, not a Minecraft Java runtime. It does not yet include a compatible desktop JVM, Minecraft libraries/assets, graphics backend, or game launch pipeline.

## Build
From this directory, with Android SDK, NDK and CMake installed:
`gradle assembleDebug`

GitHub Actions workflow: `.github/workflows/build-universe.yml`

## Build notes (0.2 build-fix)
- Gradle 8.10.2 + Android Gradle Plugin 8.7.3, Java 17, NDK 26.1.10909125, CMake 3.22.1, ABIs: arm64-v8a, armeabi-v7a, x86, x86_64.
- Only the `terra-android` module is built: `gradle :terra-android:assembleDebug`
- APK output: `terra-android/build/outputs/apk/debug/`
- The workflow installs SDK/NDK/CMake itself; no Gradle wrapper is included (the workflow provisions Gradle).
