#include <jni.h>
#include <cstdint>
#include <string>
#include <vector>

#include "solarcrystal.h"
#include "class_reader.h"

extern "C" JNIEXPORT jstring JNICALL
Java_com_universe_solarcrystal_NativeBridge_nativeVersion(JNIEnv* env, jclass) {
    return env->NewStringUTF(solarcrystal::version());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_universe_solarcrystal_NativeBridge_nativeStatus(JNIEnv* env, jclass) {
    const auto message = solarcrystal::status();
    return env->NewStringUTF(message.c_str());
}

extern "C" JNIEXPORT jint JNICALL
Java_com_universe_solarcrystal_NativeBridge_nativeAdd(JNIEnv*, jclass, jint a, jint b) {
    return solarcrystal::add(a, b);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_universe_solarcrystal_NativeBridge_nativeInspectClass(JNIEnv* env, jclass, jbyteArray class_bytes) {
    if (class_bytes == nullptr) {
        return env->NewStringUTF("SolarCrystal Class Reader: ERROR\nInput byte array is null");
    }

    const jsize length = env->GetArrayLength(class_bytes);
    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(length));
    if (length > 0) {
        env->GetByteArrayRegion(class_bytes, 0, length, reinterpret_cast<jbyte*>(bytes.data()));
        if (env->ExceptionCheck()) return nullptr;
    }

    const std::string result = solarcrystal::inspect_class_file(bytes.data(), bytes.size());
    return env->NewStringUTF(result.c_str());
}
