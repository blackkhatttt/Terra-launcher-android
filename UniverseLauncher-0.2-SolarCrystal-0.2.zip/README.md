# Universe Launcher 0.2 + SolarCrystal 0.2

Universe Launcher is an Android launcher prototype. SolarCrystal is its independently developed native Java-runtime project.

## SolarCrystal 0.2: class-file reader milestone

This version adds the first JVM class-file parser in native C++:

- Validates the `CAFEBABE` class-file magic and checks input bounds.
- Reads class-file minor/major versions and the constant pool (including modern constant-pool tags through Java 17-era class files).
- Resolves the class and superclass names.
- Reads interfaces, fields, methods, and class/member attributes.
- Recognizes method `Code` attributes and reports max-stack/max-local values, bytecode lengths, exception-table counts, and nested attribute counts.
- Exposes `NativeBridge.nativeInspectClass(byte[])` through JNI.
- Adds a launcher button, **TEST SOLARCRYSTAL CLASS READER**, that parses a small valid sample class file.

The parser is deliberately a reader, not yet a verifier or interpreter. It does not execute bytecode, resolve Java classes, provide the Java standard library, or launch Minecraft.

## Existing launcher functionality preserved

- Universe Launcher Android UI and profile creation.
- `terra-core` profile model.
- Existing SolarCrystal JNI version, status, and arithmetic test methods.
- Existing Gradle, CMake, NDK, and GitHub Actions build configuration.

## Build

From this directory, with Android SDK, NDK and CMake installed:

```bash
gradle :terra-android:assembleDebug
```

APK output: `terra-android/build/outputs/apk/debug/`.

GitHub Actions workflow: `.github/workflows/build-universe.yml`.

## Next SolarCrystal milestones

1. Add a bytecode instruction decoder with safe instruction-boundary handling.
2. Implement a small interpreter for a carefully selected set of JVM opcodes.
3. Add constant-pool resolution and a minimal runtime value/operand-stack model.
4. Expand compatibility through tests before attempting Minecraft integration.

## Important compatibility note

A class-file parser alone is not a JVM. Minecraft requires a much larger runtime surface, including class loading, verification, bytecode execution, Java APIs, threading, networking, graphics integration, and native library support. Those capabilities will be developed and tested incrementally.
