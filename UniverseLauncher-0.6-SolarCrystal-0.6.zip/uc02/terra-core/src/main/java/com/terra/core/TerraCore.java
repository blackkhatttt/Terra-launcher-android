package com.terra.core;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class TerraCore {
    public static final String NAME = "Terra Launcher";
    public static final String VERSION = "0.1.0";

    private TerraCore() {}

    public static List<String> supportedPlatforms() {
        return Collections.unmodifiableList(Arrays.asList(
                "Windows", "Linux", "macOS", "Android"
        ));
    }

    public static String welcomeMessage() {
        return NAME + " v" + VERSION + " - Core initialized.";
    }
}
