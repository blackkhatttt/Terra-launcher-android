package com.terra.core;

import java.util.Objects;

/** A named Minecraft installation profile. */
public final class InstanceProfile {
    private final String name;
    private final String minecraftVersion;
    private final String loader;
    private final int memoryMb;

    public InstanceProfile(String name, String minecraftVersion, String loader, int memoryMb) {
        this.name = requireText(name, "name");
        this.minecraftVersion = requireText(minecraftVersion, "minecraftVersion");
        this.loader = requireText(loader, "loader");
        if (memoryMb < 512) {
            throw new IllegalArgumentException("memoryMb must be at least 512 MB");
        }
        this.memoryMb = memoryMb;
    }

    private static String requireText(String value, String field) {
        Objects.requireNonNull(value, field + " cannot be null");
        if (value.trim().isEmpty()) {
            throw new IllegalArgumentException(field + " cannot be blank");
        }
        return value.trim();
    }

    public String getName() { return name; }
    public String getMinecraftVersion() { return minecraftVersion; }
    public String getLoader() { return loader; }
    public int getMemoryMb() { return memoryMb; }

    public static InstanceProfile vanilla(String name, String version) {
        return new InstanceProfile(name, version, "Vanilla", 2048);
    }
}
