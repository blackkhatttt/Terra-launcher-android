package com.terra.core;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

public final class InstanceManager {
    private final Map<String, InstanceProfile> profiles = new LinkedHashMap<>();

    public void add(InstanceProfile profile) {
        if (profiles.containsKey(profile.getName())) {
            throw new IllegalArgumentException(
                    "An instance named '" + profile.getName() + "' already exists."
            );
        }
        profiles.put(profile.getName(), profile);
    }

    public Optional<InstanceProfile> find(String name) {
        return Optional.ofNullable(profiles.get(name));
    }

    public Collection<InstanceProfile> all() {
        return Collections.unmodifiableList(new ArrayList<>(profiles.values()));
    }

    public boolean remove(String name) {
        return profiles.remove(name) != null;
    }
}
