cmake_minimum_required(VERSION 3.22.1)
project(SolarCrystal VERSION 0.5.0 LANGUAGES CXX)

add_library(solarcrystal SHARED
    solarcrystal.cpp
    class_reader.cpp
    class_method_executor.cpp
    vm_runtime.cpp
    jni_bridge.cpp
)

target_include_directories(solarcrystal PRIVATE include)
target_compile_features(solarcrystal PRIVATE cxx_std_17)
target_compile_definitions(solarcrystal PRIVATE SOLARCRYSTAL_VERSION="${PROJECT_VERSION}")
