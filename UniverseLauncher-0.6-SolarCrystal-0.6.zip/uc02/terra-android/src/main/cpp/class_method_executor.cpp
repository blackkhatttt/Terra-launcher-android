#include "class_method_executor.h"

#include "vm_runtime.h"

#include <cstdint>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace solarcrystal {
namespace {

class Reader {
public:
    Reader(const std::uint8_t* bytes, std::size_t length)
        : data_(bytes), size_(length) {

        if (bytes == nullptr && length != 0)
            throw std::runtime_error("Null class-file buffer");
    }

    std::uint8_t u1() {
        require(1);
        return data_[position_++];
    }

    std::uint16_t u2() {
        return static_cast<std::uint16_t>(
            (u1() << 8) | u1()
        );
    }

    std::uint32_t u4() {
        return
            (static_cast<std::uint32_t>(u1()) << 24) |
            (static_cast<std::uint32_t>(u1()) << 16) |
            (static_cast<std::uint32_t>(u1()) << 8) |
            static_cast<std::uint32_t>(u1());
    }

    std::string utf8(std::uint16_t length) {
        require(length);

        std::string value(
            reinterpret_cast<const char*>(data_ + position_),
            length
        );

        position_ += length;
        return value;
    }

    void skip(std::size_t amount) {
        require(amount);
        position_ += amount;
    }

    std::size_t remaining() const {
        return size_ - position_;
    }

    const std::uint8_t* current() const {
        return data_ + position_;
    }

private:
    const std::uint8_t* data_;
    std::size_t size_;
    std::size_t position_ = 0;

    void require(std::size_t amount) const {
        if (amount > size_ - position_)
            throw std::runtime_error(
                "Unexpected end of .class file"
            );
    }
};

struct CpEntry {
    std::uint8_t tag = 0;
    std::uint16_t reference = 0;
    std::string text;
};

std::string cp_utf8(
    const std::vector<CpEntry>& cp,
    std::uint16_t index
) {
    if (index == 0 ||
        index >= cp.size() ||
        cp[index].tag != 1) {
        throw std::runtime_error(
            "Invalid constant-pool UTF8 reference"
        );
    }

    return cp[index].text;
}

void skip_attributes(Reader& reader, std::uint16_t count) {
    for (std::uint16_t i = 0; i < count; ++i) {
        (void)reader.u2();

        const std::uint32_t length = reader.u4();
        reader.skip(length);
    }
}

std::size_t count_int_arguments(
    const std::string& descriptor
) {
    if (descriptor.empty() || descriptor[0] != '(')
        throw std::runtime_error("Invalid method descriptor");

    std::size_t position = 1;
    std::size_t count = 0;

    while (position < descriptor.size() &&
           descriptor[position] != ')') {

        if (descriptor[position] != 'I') {
            throw std::runtime_error(
                "SolarCrystal 0.6 supports only integer parameters"
            );
        }

        ++count;
        ++position;
    }

    if (position >= descriptor.size() ||
        descriptor[position] != ')') {
        throw std::runtime_error("Invalid method descriptor");
    }

    if (descriptor.substr(position + 1) != "I") {
        throw std::runtime_error(
            "SolarCrystal 0.6 currently supports only integer return values"
        );
    }

    return count;
}

struct ExtractedCode {
    bool found = false;
    std::uint16_t access = 0;
    std::uint16_t max_stack = 0;
    std::uint16_t max_locals = 0;

    std::vector<std::uint8_t> bytes;

    std::string class_name;
};

ExtractedCode parse_method(
    const std::uint8_t* data,
    std::size_t size,
    const std::string& wanted_name,
    const std::string& wanted_descriptor
) {
    Reader reader(data, size);

    if (reader.u4() != 0xCAFEBABE)
        throw std::runtime_error(
            "Invalid class-file magic (expected CAFEBABE)"
        );

    (void)reader.u2();

    const std::uint16_t major = reader.u2();

    if (major < 45 || major > 70) {
        throw std::runtime_error(
            "Unsupported class-file version: " +
            std::to_string(major)
        );
    }

    const std::uint16_t cp_count = reader.u2();

    if (cp_count == 0)
        throw std::runtime_error("Invalid constant_pool_count");

    std::vector<CpEntry> cp(cp_count);

    for (std::uint16_t i = 1; i < cp_count; ++i) {
        CpEntry& entry = cp[i];
        entry.tag = reader.u1();

        switch (entry.tag) {
            case 1:
                entry.text = reader.utf8(reader.u2());
                break;

            case 3:
            case 4:
                reader.skip(4);
                break;

            case 5:
            case 6:
                reader.skip(8);

                if (i + 1 >= cp_count)
                    throw std::runtime_error(
                        "Invalid two-slot constant-pool entry"
                    );

                ++i;
                break;

            case 7:
                entry.reference = reader.u2();
                break;

            case 8:
            case 16:
            case 19:
            case 20:
                reader.skip(2);
                break;

            case 9:
            case 10:
            case 11:
            case 12:
            case 17:
            case 18:
                reader.skip(4);
                break;

            case 15:
                reader.skip(3);
                break;

            default:
                throw std::runtime_error(
                    "Unsupported constant-pool tag " +
                    std::to_string(entry.tag)
                );
        }
    }

    (void)reader.u2();

    const std::uint16_t this_class = reader.u2();

    (void)reader.u2();

    if (this_class == 0 ||
        this_class >= cp.size() ||
        cp[this_class].tag != 7) {
        throw std::runtime_error(
            "Invalid this_class reference"
        );
    }

    const std::uint16_t interfaces = reader.u2();

    reader.skip(
        static_cast<std::size_t>(interfaces) * 2
    );

    const std::uint16_t fields = reader.u2();

    for (std::uint16_t i = 0; i < fields; ++i) {
        reader.skip(6);
        skip_attributes(reader, reader.u2());
    }

    ExtractedCode result;

    result.class_name = cp_utf8(
        cp,
        cp[this_class].reference
    );

    const std::uint16_t methods = reader.u2();

    for (std::uint16_t i = 0; i < methods; ++i) {
        const std::uint16_t access = reader.u2();

        const std::string name = cp_utf8(
            cp,
            reader.u2()
        );

        const std::string descriptor = cp_utf8(
            cp,
            reader.u2()
        );

        const std::uint16_t attribute_count = reader.u2();

        const bool target =
            name == wanted_name &&
            descriptor == wanted_descriptor;

        for (std::uint16_t a = 0; a < attribute_count; ++a) {
            const std::string attribute_name = cp_utf8(
                cp,
                reader.u2()
            );

            const std::uint32_t attribute_length = reader.u4();

            if (attribute_length > reader.remaining()) {
                throw std::runtime_error(
                    "Method attribute exceeds class-file bounds"
                );
            }

            if (target && attribute_name == "Code") {
                if (result.found) {
                    throw std::runtime_error(
                        "Duplicate Code attribute for requested method"
                    );
                }

                Reader code(reader.current(), attribute_length);

                result.max_stack = code.u2();
                result.max_locals = code.u2();

                const std::uint32_t code_length = code.u4();

                if (code_length == 0 || code_length > 65535) {
                    throw std::runtime_error(
                        "Invalid JVM Code length"
                    );
                }

                if (code_length > code.remaining()) {
                    throw std::runtime_error(
                        "Bytecode length exceeds Code attribute"
                    );
                }

                result.bytes.reserve(code_length);

                for (std::uint32_t b = 0; b < code_length; ++b)
                    result.bytes.push_back(code.u1());

                const std::uint16_t exception_count = code.u2();

                if (exception_count != 0) {
                    throw std::runtime_error(
                        "Methods with exception handlers are not supported in SolarCrystal 0.6"
                    );
                }

                const std::uint16_t nested = code.u2();

                skip_attributes(code, nested);

                if (code.remaining() != 0) {
                    throw std::runtime_error(
                        "Malformed Code attribute length"
                    );
                }

                result.access = access;
                result.found = true;
            }

            reader.skip(attribute_length);
        }

        if (target && (access & 0x0100)) {
            throw std::runtime_error(
                "Native methods do not contain executable Code attributes"
            );
        }

        if (target && (access & 0x0400)) {
            throw std::runtime_error(
                "Abstract methods do not contain executable Code attributes"
            );
        }
    }

    skip_attributes(reader, reader.u2());

    if (reader.remaining() != 0) {
        throw std::runtime_error(
            "Unexpected trailing bytes after class attributes"
        );
    }

    if (!result.found) {
        throw std::runtime_error(
            "Method not found or it has no Code attribute: " +
            wanted_name + wanted_descriptor
        );
    }

    if ((result.access & 0x0008) == 0) {
        throw std::runtime_error(
            "Only static methods are supported by this test runner"
        );
    }

    (void)count_int_arguments(wanted_descriptor);

    return result;
}

}

std::string execute_class_method(
    const std::uint8_t* data,
    std::size_t size,
    const std::string& method_name,
    const std::string& method_descriptor,
    const std::vector<std::int32_t>& arguments
) {
    try {
        if (size == 0 || size > 16 * 1024 * 1024) {
            throw std::runtime_error(
                "Class file is empty or exceeds 16 MiB limit"
            );
        }

        if (method_name.empty() ||
            method_name.size() > 256 ||
            method_descriptor.size() > 256) {
            throw std::runtime_error(
                "Invalid method name or descriptor length"
            );
        }

        const std::size_t expected_arguments =
            count_int_arguments(method_descriptor);

        if (arguments.size() != expected_arguments) {
            throw std::runtime_error(
                "Argument count does not match method descriptor"
            );
        }

        ExtractedCode method = parse_method(
            data,
            size,
            method_name,
            method_descriptor
        );

        if (arguments.size() > method.max_locals) {
            throw std::runtime_error(
                "Arguments exceed method max_locals"
            );
        }

        const std::string execution = execute_bytecode(
            method.bytes.data(),
            method.bytes.size(),
            method.max_stack,
            method.max_locals,
            arguments
        );

        std::ostringstream output;

        output << "SolarCrystal Class VM: "
               << (
                   execution.find("SolarCrystal VM: OK") == 0
                   ? "OK"
                   : "ERROR"
               )
               << "\n"
               << "Class: " << method.class_name << "\n"
               << "Class file size: " << size << " bytes\n"
               << "Method: " << method_name
               << method_descriptor << "\n"
               << "Arguments: " << arguments.size() << "\n"
               << "Extracted bytecode: "
               << method.bytes.size() << " bytes\n"
               << "max_stack: " << method.max_stack << "\n"
               << "max_locals: " << method.max_locals
               << "\n\n"
               << execution;

        return output.str();

    } catch (const std::exception& error) {
        return std::string(
            "SolarCrystal Class VM: ERROR\n"
        ) + error.what();
    }
}

}
