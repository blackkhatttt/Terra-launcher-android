#include "class_reader.h"

#include <iomanip>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace solarcrystal {
namespace {

class Reader {
public:
    Reader(const std::uint8_t* bytes, std::size_t length) : data(bytes), size(length) {
        if (bytes == nullptr && length != 0) {
            throw std::runtime_error("Null class-file buffer");
        }
    }

    std::uint8_t u1() {
        require(1);
        return data[position++];
    }

    std::uint16_t u2() {
        return static_cast<std::uint16_t>((static_cast<std::uint16_t>(u1()) << 8) | u1());
    }

    std::uint32_t u4() {
        return (static_cast<std::uint32_t>(u1()) << 24)
             | (static_cast<std::uint32_t>(u1()) << 16)
             | (static_cast<std::uint32_t>(u1()) << 8)
             | static_cast<std::uint32_t>(u1());
    }

    std::string utf8(std::uint16_t length) {
        require(length);
        std::string result(reinterpret_cast<const char*>(data + position), length);
        position += length;
        return result;
    }

    void skip(std::size_t amount) {
        require(amount);
        position += amount;
    }

    std::size_t remaining() const { return size - position; }

private:
    const std::uint8_t* data;
    std::size_t size;
    std::size_t position = 0;

    void require(std::size_t amount) const {
        if (amount > size - position) {
            throw std::runtime_error("Unexpected end of .class file");
        }
    }
};

struct Constant {
    std::uint8_t tag = 0;
    std::string text;
    std::uint16_t first = 0;
};

std::string constant_name(const std::vector<Constant>& pool, std::uint16_t index) {
    if (index == 0 || index >= pool.size()) return "<invalid-index>";
    const Constant& entry = pool[index];
    if (entry.tag != 7 || entry.first == 0 || entry.first >= pool.size()) {
        return "<invalid-class-name>";
    }
    const Constant& name = pool[entry.first];
    return name.tag == 1 ? name.text : "<invalid-class-name>";
}

std::string access_flags(std::uint16_t flags, bool method) {
    std::vector<std::string> names;
    if (flags & 0x0001) names.emplace_back("public");
    if (flags & 0x0002) names.emplace_back("private");
    if (flags & 0x0004) names.emplace_back("protected");
    if (flags & 0x0008) names.emplace_back("static");
    if (flags & 0x0010) names.emplace_back(method ? "final" : "final");
    if (flags & 0x0020) names.emplace_back(method ? "synchronized" : "super");
    if (flags & 0x0040) names.emplace_back(method ? "bridge" : "volatile");
    if (flags & 0x0080) names.emplace_back(method ? "varargs" : "transient");
    if (flags & 0x0100) names.emplace_back("native");
    if (flags & 0x0200) names.emplace_back("interface");
    if (flags & 0x0400) names.emplace_back("abstract");
    if (flags & 0x0800) names.emplace_back("strict");
    if (flags & 0x1000) names.emplace_back("synthetic");
    if (flags & 0x2000) names.emplace_back("annotation");
    if (flags & 0x4000) names.emplace_back("enum");
    if (flags & 0x8000) names.emplace_back("module");
    std::ostringstream out;
    for (std::size_t i = 0; i < names.size(); ++i) {
        if (i) out << ' ';
        out << names[i];
    }
    return out.str();
}

std::string pool_utf8(const std::vector<Constant>& pool, std::uint16_t index) {
    if (index == 0 || index >= pool.size() || pool[index].tag != 1) {
        return "<invalid-utf8-index>";
    }
    return pool[index].text;
}

void skip_attributes(Reader& reader, std::uint16_t count) {
    for (std::uint16_t i = 0; i < count; ++i) {
        (void)reader.u2(); // attribute_name_index
        const std::uint32_t length = reader.u4();
        reader.skip(length);
    }
}

} // namespace

std::string inspect_class_file(const std::uint8_t* data, std::size_t size) {
    try {
        Reader reader(data, size);
        const std::uint32_t magic = reader.u4();
        if (magic != 0xCAFEBABE) {
            throw std::runtime_error("Invalid class-file magic (expected CAFEBABE)");
        }

        const std::uint16_t minor = reader.u2();
        const std::uint16_t major = reader.u2();
        const std::uint16_t pool_count = reader.u2();
        if (pool_count == 0) throw std::runtime_error("Invalid constant_pool_count");

        std::vector<Constant> pool(pool_count);
        for (std::uint16_t i = 1; i < pool_count; ++i) {
            Constant& entry = pool[i];
            entry.tag = reader.u1();
            switch (entry.tag) {
                case 1: { // CONSTANT_Utf8
                    entry.text = reader.utf8(reader.u2());
                    break;
                }
                case 3: case 4: // Integer / Float
                    reader.skip(4);
                    break;
                case 5: case 6: // Long / Double occupy two pool slots
                    reader.skip(8);
                    if (i + 1 >= pool_count) throw std::runtime_error("Invalid two-slot constant");
                    ++i;
                    break;
                case 7: case 8: case 16: case 19: case 20:
                    entry.first = reader.u2();
                    break;
                case 9: case 10: case 11: case 12: case 17: case 18:
                    reader.skip(4);
                    break;
                case 15:
                    reader.skip(3);
                    break;
                default:
                    throw std::runtime_error("Unsupported constant-pool tag " + std::to_string(entry.tag));
            }
        }

        const std::uint16_t flags = reader.u2();
        const std::uint16_t this_class = reader.u2();
        const std::uint16_t super_class = reader.u2();
        const std::string class_name = constant_name(pool, this_class);
        const std::string super_name = super_class == 0 ? "<none>" : constant_name(pool, super_class);

        const std::uint16_t interface_count = reader.u2();
        std::vector<std::string> interfaces;
        interfaces.reserve(interface_count);
        for (std::uint16_t i = 0; i < interface_count; ++i) {
            interfaces.push_back(constant_name(pool, reader.u2()));
        }

        const std::uint16_t field_count = reader.u2();
        std::vector<std::string> fields;
        fields.reserve(field_count);
        for (std::uint16_t i = 0; i < field_count; ++i) {
            const std::uint16_t field_flags = reader.u2();
            const std::string name = pool_utf8(pool, reader.u2());
            const std::string descriptor = pool_utf8(pool, reader.u2());
            fields.push_back(access_flags(field_flags, false) + " " + name + " " + descriptor);
            skip_attributes(reader, reader.u2());
        }

        const std::uint16_t method_count = reader.u2();
        std::vector<std::string> methods;
        methods.reserve(method_count);
        std::size_t code_methods = 0;
        std::size_t total_code_bytes = 0;
        for (std::uint16_t i = 0; i < method_count; ++i) {
            const std::uint16_t method_flags = reader.u2();
            const std::string name = pool_utf8(pool, reader.u2());
            const std::string descriptor = pool_utf8(pool, reader.u2());
            std::ostringstream method_line;
            method_line << access_flags(method_flags, true) << ' ' << name << ' ' << descriptor;

            const std::uint16_t attribute_count = reader.u2();
            for (std::uint16_t a = 0; a < attribute_count; ++a) {
                const std::uint16_t attribute_name_index = reader.u2();
                const std::uint32_t attribute_length = reader.u4();
                const std::string attribute_name = pool_utf8(pool, attribute_name_index);
                if (attribute_length > reader.remaining()) {
                    throw std::runtime_error("Attribute length exceeds remaining class-file data");
                }
                if (attribute_name == "Code") {
                    // Parse the Code header and byte array using a bounded sub-reader.
                    Reader code_reader(data + (size - reader.remaining()), attribute_length);
                    const std::uint16_t max_stack = code_reader.u2();
                    const std::uint16_t max_locals = code_reader.u2();
                    const std::uint32_t code_length = code_reader.u4();
                    code_reader.skip(code_length);
                    const std::uint16_t exception_count = code_reader.u2();
                    code_reader.skip(static_cast<std::size_t>(exception_count) * 8);
                    const std::uint16_t nested_attributes = code_reader.u2();
                    skip_attributes(code_reader, nested_attributes);
                    if (code_reader.remaining() != 0) {
                        throw std::runtime_error("Malformed Code attribute length");
                    }
                    ++code_methods;
                    total_code_bytes += code_length;
                    method_line << " [max_stack=" << max_stack
                                << ", max_locals=" << max_locals
                                << ", bytecode=" << code_length << " bytes"
                                << ", exceptions=" << exception_count
                                << ", nested_attributes=" << nested_attributes << "]";
                    reader.skip(attribute_length);
                } else {
                    reader.skip(attribute_length);
                }
            }
            methods.push_back(method_line.str());
        }

        skip_attributes(reader, reader.u2()); // class attributes
        if (reader.remaining() != 0) {
            throw std::runtime_error("Unexpected trailing bytes after class attributes");
        }

        std::ostringstream out;
        out << "SolarCrystal Class Reader: OK\n"
            << "Class: " << class_name << "\n"
            << "Superclass: " << super_name << "\n"
            << "Version: " << major << '.' << minor << "\n"
            << "Access: " << access_flags(flags, false) << "\n"
            << "Constant pool entries: " << (pool_count - 1) << "\n"
            << "Interfaces: " << interfaces.size() << "\n"
            << "Fields: " << fields.size() << "\n";
        for (const auto& field : fields) out << "  FIELD " << field << "\n";
        out << "Methods: " << methods.size() << "\n";
        for (const auto& method : methods) out << "  METHOD " << method << "\n";
        out << "Methods with Code: " << code_methods << "\n"
            << "Total bytecode bytes: " << total_code_bytes << "\n"
            << "File size: " << size << " bytes";
        return out.str();
    } catch (const std::exception& error) {
        return std::string("SolarCrystal Class Reader: ERROR\n") + error.what();
    }
}

} // namespace solarcrystal
