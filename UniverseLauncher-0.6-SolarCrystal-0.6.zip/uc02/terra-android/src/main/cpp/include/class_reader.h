#pragma once

#include <cstddef>
#include <cstdint>
#include <string>

namespace solarcrystal {

// Reads and validates the structural metadata of a JVM .class file.
// This is a parser only: it does not verify or execute bytecode.
std::string inspect_class_file(const std::uint8_t* data, std::size_t size);

}
