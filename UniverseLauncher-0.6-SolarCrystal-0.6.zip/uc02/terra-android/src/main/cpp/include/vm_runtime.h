#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace solarcrystal {

std::string execute_bytecode(
    const std::uint8_t* code,
    std::size_t code_size,
    std::uint16_t max_stack,
    std::uint16_t max_locals,
    const std::vector<std::int32_t>& initial_locals = {}
);

}
