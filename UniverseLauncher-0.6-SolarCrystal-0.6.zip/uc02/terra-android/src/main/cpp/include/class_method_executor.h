#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace solarcrystal {

std::string execute_class_method(
    const std::uint8_t* data,
    std::size_t size,
    const std::string& method_name,
    const std::string& method_descriptor,
    const std::vector<std::int32_t>& arguments = {}
);

}
