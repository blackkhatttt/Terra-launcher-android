#pragma once
#include <string>

namespace solarcrystal {
    const char* version() noexcept;
    std::string status();
    int add(int a, int b) noexcept;
}
