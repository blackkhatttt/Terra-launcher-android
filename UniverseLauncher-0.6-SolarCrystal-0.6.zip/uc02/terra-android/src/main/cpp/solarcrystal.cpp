#include "solarcrystal.h"

namespace solarcrystal {
    const char* version() noexcept {
#ifdef SOLARCRYSTAL_VERSION
        return SOLARCRYSTAL_VERSION;
#else
        return "0.2.0";
#endif
    }

    std::string status() {
        return "SolarCrystal native core initialized; JVM class reader and bytecode interpreter available";
    }

    int add(int a, int b) noexcept {
        return a + b;
    }
}
