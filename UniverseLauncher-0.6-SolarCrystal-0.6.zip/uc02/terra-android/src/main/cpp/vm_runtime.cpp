#include "vm_runtime.h"

#include <cstdint>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <vector>

namespace solarcrystal {
namespace {

class Interpreter {
public:
    Interpreter(
        const std::uint8_t* bytes,
        std::size_t length,
        std::uint16_t stack_limit,
        std::uint16_t local_count,
        const std::vector<std::int32_t>& initial_locals
    )
        : code(bytes),
          size(length),
          max_stack(stack_limit),
          locals(local_count, 0) {

        if (!bytes && length)
            throw std::runtime_error("Null bytecode buffer");

        if (!stack_limit && length)
            throw std::runtime_error("max_stack must be greater than zero");

        if (initial_locals.size() > locals.size())
            throw std::runtime_error("Arguments exceed max_locals");

        for (std::size_t i = 0; i < initial_locals.size(); ++i)
            locals[i] = initial_locals[i];
    }

    std::string run() {
        std::size_t steps = 0;

        while (pc < size) {
            if (++steps > 1000000)
                throw std::runtime_error("Execution step limit exceeded");

            const std::size_t opcode_pc = pc;
            const std::uint8_t op = read_u1();

            switch (op) {
                case 0x02:
                    push(-1);
                    break;

                case 0x03:
                case 0x04:
                case 0x05:
                case 0x06:
                case 0x07:
                case 0x08:
                    push(op - 0x03);
                    break;

                case 0x10:
                    push(static_cast<std::int8_t>(read_u1()));
                    break;

                case 0x11:
                    push(static_cast<std::int16_t>(read_u2()));
                    break;

                case 0x15:
                    push(local(read_u1()));
                    break;

                case 0x1a:
                case 0x1b:
                case 0x1c:
                case 0x1d:
                    push(local(op - 0x1a));
                    break;

                case 0x36:
                    store(read_u1(), pop());
                    break;

                case 0x3b:
                case 0x3c:
                case 0x3d:
                case 0x3e:
                    store(op - 0x3b, pop());
                    break;

                case 0x57:
                    (void)pop();
                    break;

                case 0x59: {
                    const auto value = pop();
                    push(value);
                    push(value);
                    break;
                }

                case 0x60: {
                    const auto b = pop();
                    const auto a = pop();
                    push(wrap_add(a, b));
                    break;
                }

                case 0x64: {
                    const auto b = pop();
                    const auto a = pop();
                    push(wrap_sub(a, b));
                    break;
                }

                case 0x68: {
                    const auto b = pop();
                    const auto a = pop();
                    push(wrap_mul(a, b));
                    break;
                }

                case 0x6c: {
                    const auto b = pop();
                    const auto a = pop();

                    if (b == 0)
                        throw std::runtime_error(
                            "ArithmeticException: division by zero"
                        );

                    if (a == std::numeric_limits<std::int32_t>::min()
                        && b == -1) {
                        push(a);
                    } else {
                        push(a / b);
                    }
                    break;
                }

                case 0x74:
                    push(static_cast<std::int32_t>(
                        0u - static_cast<std::uint32_t>(pop())
                    ));
                    break;

                case 0x84: {
                    const auto index = read_u1();
                    const auto amount =
                        static_cast<std::int8_t>(read_u1());

                    store(
                        index,
                        wrap_add(local(index), amount)
                    );
                    break;
                }

                case 0x99:
                    branch(pop() == 0, opcode_pc);
                    break;

                case 0x9a:
                    branch(pop() != 0, opcode_pc);
                    break;

                case 0x9b:
                    branch(pop() < 0, opcode_pc);
                    break;

                case 0x9c:
                    branch(pop() >= 0, opcode_pc);
                    break;

                case 0x9d:
                    branch(pop() > 0, opcode_pc);
                    break;

                case 0x9e:
                    branch(pop() <= 0, opcode_pc);
                    break;

                case 0x9f:
                    compare_branch(opcode_pc, [](auto a, auto b) {
                        return a == b;
                    });
                    break;

                case 0xa0:
                    compare_branch(opcode_pc, [](auto a, auto b) {
                        return a != b;
                    });
                    break;

                case 0xa1:
                    compare_branch(opcode_pc, [](auto a, auto b) {
                        return a < b;
                    });
                    break;

                case 0xa2:
                    compare_branch(opcode_pc, [](auto a, auto b) {
                        return a >= b;
                    });
                    break;

                case 0xa3:
                    compare_branch(opcode_pc, [](auto a, auto b) {
                        return a > b;
                    });
                    break;

                case 0xa4:
                    compare_branch(opcode_pc, [](auto a, auto b) {
                        return a <= b;
                    });
                    break;

                case 0xa7:
                    branch(true, opcode_pc);
                    break;

                case 0xac:
                    return result(
                        "Return value: " + std::to_string(pop()),
                        steps
                    );

                case 0xb1:
                    return result("Return: void", steps);

                default: {
                    std::ostringstream message;

                    message << "Unsupported opcode 0x"
                            << std::hex << unsigned(op)
                            << " at bytecode offset "
                            << std::dec << opcode_pc;

                    throw std::runtime_error(message.str());
                }
            }
        }

        throw std::runtime_error(
            "Method ended without ireturn or return"
        );
    }

private:
    const std::uint8_t* code;
    std::size_t size;
    std::size_t pc = 0;

    std::uint16_t max_stack;

    std::vector<std::int32_t> locals;
    std::vector<std::int32_t> stack;

    std::size_t peak = 0;

    std::uint8_t read_u1() {
        if (pc >= size)
            throw std::runtime_error("Truncated bytecode operand");

        return code[pc++];
    }

    std::uint16_t read_u2() {
        const auto high = read_u1();

        return static_cast<std::uint16_t>(
            (high << 8) | read_u1()
        );
    }

    void push(std::int32_t value) {
        if (stack.size() >= max_stack)
            throw std::runtime_error("Operand stack overflow");

        stack.push_back(value);

        if (stack.size() > peak)
            peak = stack.size();
    }

    std::int32_t pop() {
        if (stack.empty())
            throw std::runtime_error("Operand stack underflow");

        const auto value = stack.back();
        stack.pop_back();

        return value;
    }

    std::int32_t local(std::uint8_t index) const {
        if (index >= locals.size())
            throw std::runtime_error(
                "Local variable index out of range"
            );

        return locals[index];
    }

    void store(std::uint8_t index, std::int32_t value) {
        if (index >= locals.size())
            throw std::runtime_error(
                "Local variable index out of range"
            );

        locals[index] = value;
    }

    static std::int32_t wrap_add(
        std::int32_t a,
        std::int32_t b
    ) {
        return static_cast<std::int32_t>(
            std::uint32_t(a) + std::uint32_t(b)
        );
    }

    static std::int32_t wrap_sub(
        std::int32_t a,
        std::int32_t b
    ) {
        return static_cast<std::int32_t>(
            std::uint32_t(a) - std::uint32_t(b)
        );
    }

    static std::int32_t wrap_mul(
        std::int32_t a,
        std::int32_t b
    ) {
        return static_cast<std::int32_t>(
            std::uint32_t(a) * std::uint32_t(b)
        );
    }

    void branch(bool take, std::size_t at) {
        const auto offset =
            static_cast<std::int16_t>(read_u2());

        if (!take)
            return;

        const auto target =
            static_cast<std::int64_t>(at) + offset;

        if (target < 0 ||
            static_cast<std::uint64_t>(target) >= size) {
            throw std::runtime_error(
                "Branch target outside bytecode"
            );
        }

        pc = static_cast<std::size_t>(target);
    }

    template<class Predicate>
    void compare_branch(std::size_t at, Predicate predicate) {
        const auto b = pop();
        const auto a = pop();

        branch(predicate(a, b), at);
    }

    std::string result(
        const std::string& value,
        std::size_t steps
    ) {
        std::ostringstream output;

        output << "SolarCrystal VM: OK\n"
               << value << "\n"
               << "Executed instructions: " << steps << "\n"
               << "Operand stack peak: " << peak << "\n"
               << "Local variables: " << locals.size();

        return output.str();
    }
};

}

std::string execute_bytecode(
    const std::uint8_t* code,
    std::size_t size,
    std::uint16_t max_stack,
    std::uint16_t max_locals,
    const std::vector<std::int32_t>& initial_locals
) {
    try {
        Interpreter vm(
            code,
            size,
            max_stack,
            max_locals,
            initial_locals
        );

        return vm.run();
    } catch (const std::exception& error) {
        return std::string("SolarCrystal VM: ERROR\n")
            + error.what();
    }
}

}
