# Universe Launcher 0.5 + SolarCrystal 0.5

Universe Launcher is an Android launcher prototype. SolarCrystal is an independently developed native Java-runtime research project.

## SolarCrystal 0.5: first bytecode interpreter milestone

This release preserves the Universe Launcher UI, profile model, existing JNI methods, and the SolarCrystal 0.2 class-file reader. It adds a small native interpreter for a documented subset of JVM integer bytecode.

Implemented bytecodes:
- Integer constants: `iconst_m1` through `iconst_5`, `bipush`, `sipush`
- Integer locals: `iload`, `iload_0`–`iload_3`, `istore`, `istore_0`–`istore_3`, `iinc`
- Stack operations: `pop`, `dup`
- Integer operations: `iadd`, `isub`, `imul`, `idiv`, `ineg`
- Conditional branches: `ifeq`, `ifne`, `iflt`, `ifge`, `ifgt`, `ifle`, `if_icmpeq`, `if_icmpne`, `if_icmplt`, `if_icmpge`, `if_icmpgt`, `if_icmple`, `goto`
- Returns: `ireturn`, `return`

The interpreter checks operand-stack limits, local-variable bounds, truncated operands, invalid branch targets, division by zero, unsupported opcodes, and a maximum instruction count. The launcher exposes `NativeBridge.nativeExecuteBytecode(byte[], maxStack, maxLocals)` and includes a button that executes `bipush 20; bipush 22; iadd; ireturn`, expecting `42`.

## What this is not

SolarCrystal 0.5 is not yet a complete JVM. It does not yet load a class file and invoke a selected method from its `Code` attribute, perform bytecode verification, create Java objects, resolve method/field references, implement exceptions/garbage collection, provide the Java standard library, or run Minecraft. The current test supplies a method's bytecode array directly to the interpreter. Those capabilities remain future milestones.

## Preserved functionality

- Universe Launcher Android UI and profile creation.
- `terra-core` profile model.
- Existing SolarCrystal version, status, arithmetic, and class-reader JNI methods.
- Existing class-file parser and its Android test button.
- Existing Gradle, CMake, NDK, and GitHub Actions build configuration.

## Build

```bash
gradle :terra-android:assembleDebug
```

APK output: `terra-android/build/outputs/apk/debug/`.

GitHub Actions workflow: `.github/workflows/build-universe.yml`.


## SolarCrystal 0.5 — class method execution

SolarCrystal 0.5 adds a bounded class-file method extractor. It reads the constant pool and method table, locates a requested method's `Code` attribute, extracts `max_stack`, `max_locals`, and bytecode, then passes that bytecode to the existing integer VM. The Android test runs `TestBytecode.calculate()I` from an embedded Java 8 `.class` file and should return `42`.

Current limits: this is not a complete JVM. The test runner currently accepts static methods with descriptor `()I`, methods without exception-table handlers, and only opcodes already implemented by `vm_runtime.cpp`. It does not load dependent classes, create Java objects, resolve fields/method references, or run Minecraft.
