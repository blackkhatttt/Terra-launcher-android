public class TestBytecode {

    public static int calculate() {
        return 42;
    }

    public static int sum(int a, int b) {
        int result = a + b;
        return result;
    }

    public static int multiply(int a, int b) {
        int result = a * b;
        return result;
    }
}