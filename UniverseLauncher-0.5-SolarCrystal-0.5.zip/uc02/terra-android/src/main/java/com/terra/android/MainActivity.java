package com.terra.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.terra.core.InstanceManager;
import com.terra.core.InstanceProfile;
import com.terra.core.TerraCore;
import com.universe.solarcrystal.NativeBridge;

public class MainActivity extends Activity {
    private final InstanceManager instances = new InstanceManager();
    private LinearLayout profileContainer;
    private TextView status;

    private final int background = Color.rgb(14, 22, 18);
    private final int panel = Color.rgb(26, 40, 32);
    private final int green = Color.rgb(55, 190, 119);
    private final int white = Color.rgb(240, 247, 242);
    private final int muted = Color.rgb(171, 190, 178);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildInterface();
        addProfile(InstanceProfile.vanilla("My Minecraft", "1.21.1"));
    }

    private void buildInterface() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(background);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(34), dp(22), dp(28));
        scroll.addView(page);

        TextView logo = new TextView(this);
        logo.setText("UNIVERSE");
        logo.setTextColor(green);
        logo.setTextSize(34);
        logo.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        page.addView(logo);

        TextView subtitle = new TextView(this);
        subtitle.setText("LAUNCHER  •  ANDROID EDITION");
        subtitle.setTextColor(muted);
        subtitle.setTextSize(12);
        subtitle.setPadding(0, 0, 0, dp(24));
        page.addView(subtitle);

        TextView heading = new TextView(this);
        heading.setText("YOUR INSTANCES");
        heading.setTextColor(white);
        heading.setTextSize(16);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        page.addView(heading);

        profileContainer = new LinearLayout(this);
        profileContainer.setOrientation(LinearLayout.VERTICAL);
        profileContainer.setPadding(0, dp(12), 0, dp(12));
        page.addView(profileContainer);

        Button create = makeButton("+  CREATE PROFILE", green, Color.BLACK);
        create.setOnClickListener(v -> showCreateDialog());
        page.addView(create);

        Button play = makeButton("PLAY", Color.rgb(24, 132, 79), Color.WHITE);
        LinearLayout.LayoutParams playParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(56));
        playParams.topMargin = dp(14);
        page.addView(play, playParams);
        play.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("SolarCrystal Runtime")
                .setMessage("SolarCrystal is integrated and its native bridge is available. Minecraft Java runtime compatibility is still under development.")
                .setPositiveButton("OK", null)
                .show());

        Button testClassReader = makeButton("TEST SOLARCRYSTAL CLASS READER", panel, green);
        LinearLayout.LayoutParams readerParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(50));
        readerParams.topMargin = dp(10);
        page.addView(testClassReader, readerParams);
        testClassReader.setOnClickListener(v -> runClassReaderTest());

        Button testVm = makeButton("TEST SOLARCRYSTAL BYTECODE VM", panel, green);
        LinearLayout.LayoutParams vmParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(50));
        vmParams.topMargin = dp(8);
        page.addView(testVm, vmParams);
        testVm.setOnClickListener(v -> runBytecodeVmTest());

        Button testClassVm = makeButton("TEST SOLARCRYSTAL .CLASS EXECUTION", panel, green);
        LinearLayout.LayoutParams classVmParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(50));
        classVmParams.topMargin = dp(8);
        page.addView(testClassVm, classVmParams);
        testClassVm.setOnClickListener(v -> runClassMethodTest());

        status = new TextView(this);
        try {
            status.setText("SolarCrystal " + NativeBridge.nativeVersion()
                    + " • " + NativeBridge.nativeStatus()
                    + " • JNI test: " + NativeBridge.nativeAdd(20, 22));
        } catch (UnsatisfiedLinkError error) {
            status.setText("SolarCrystal native library could not be loaded.");
        }
        status.setTextColor(muted);
        status.setTextSize(12);
        status.setPadding(0, dp(20), 0, 0);
        page.addView(status);

        setContentView(scroll);
    }


    private void runClassReaderTest() {
        // Minimal valid Java 8 class file: public class Test extends java.lang.Object.
        byte[] sampleClass = new byte[] {
                (byte) 0xCA, (byte) 0xFE, (byte) 0xBA, (byte) 0xBE,
                0x00, 0x00, 0x00, 0x34, 0x00, 0x05,
                0x01, 0x00, 0x04, 0x54, 0x65, 0x73, 0x74,
                0x07, 0x00, 0x01,
                0x01, 0x00, 0x10, 0x6A, 0x61, 0x76, 0x61, 0x2F,
                0x6C, 0x61, 0x6E, 0x67, 0x2F, 0x4F, 0x62, 0x6A,
                0x65, 0x63, 0x74,
                0x07, 0x00, 0x03,
                0x00, 0x21, 0x00, 0x02, 0x00, 0x04,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
        };

        try {
            String result = NativeBridge.nativeInspectClass(sampleClass);
            new AlertDialog.Builder(this)
                    .setTitle("SolarCrystal • Class Reader Test")
                    .setMessage(result)
                    .setPositiveButton("OK", null)
                    .show();
        } catch (UnsatisfiedLinkError error) {
            new AlertDialog.Builder(this)
                    .setTitle("Class Reader unavailable")
                    .setMessage(error.toString())
                    .setPositiveButton("OK", null)
                    .show();
        }
    }

    private void runBytecodeVmTest() {
        // JVM bytecode: bipush 20; bipush 22; iadd; ireturn.
        byte[] code = new byte[] { 0x10, 0x14, 0x10, 0x16, 0x60, (byte) 0xac };
        try {
            String result = NativeBridge.nativeExecuteBytecode(code, 2, 0);
            new AlertDialog.Builder(this)
                    .setTitle("SolarCrystal 0.5 • Bytecode VM Test")
                    .setMessage(result)
                    .setPositiveButton("OK", null)
                    .show();
        } catch (UnsatisfiedLinkError error) {
            new AlertDialog.Builder(this)
                    .setTitle("Bytecode VM unavailable")
                    .setMessage(error.toString())
                    .setPositiveButton("OK", null)
                    .show();
        }
    }

    private void runClassMethodTest() {
        // A real .class file compiled with javac --release 8 from TestBytecode.java.
        // Its static calculate() method contains bytecode for 20 + 22.
        final String encodedClass = "yv66vgAAADQADAoAAgADBwAEDAAFAAYBABBqYXZhL2xhbmcvT2JqZWN0AQAGPGluaXQ+AQADKClWBwAIAQAMVGVzdEJ5dGVjb2RlAQAEQ29kZQEACWNhbGN1bGF0ZQEAAygpSQAhAAcAAgAAAAAAAgABAAUABgABAAkAAAARAAEAAQAAAAUqtwABsQAAAAAACQAKAAsAAQAJAAAAFgACAAIAAAAKEBQ7EBY8GhtgrAAAAAAAAA==";
        try {
            byte[] classBytes = Base64.decode(encodedClass, Base64.DEFAULT);
            String result = NativeBridge.nativeExecuteClassMethod(
                    classBytes, "calculate", "()I");
            new AlertDialog.Builder(this)
                    .setTitle("SolarCrystal 0.5 • .class Method Execution")
                    .setMessage(result)
                    .setPositiveButton("OK", null)
                    .show();
        } catch (UnsatisfiedLinkError error) {
            new AlertDialog.Builder(this)
                    .setTitle("SolarCrystal Class VM unavailable")
                    .setMessage(error.toString())
                    .setPositiveButton("OK", null)
                    .show();
        } catch (IllegalArgumentException error) {
            new AlertDialog.Builder(this)
                    .setTitle("Invalid class test data")
                    .setMessage(error.toString())
                    .setPositiveButton("OK", null)
                    .show();
        }
    }

    private void showCreateDialog() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Profile name");

        new AlertDialog.Builder(this)
                .setTitle("New Minecraft profile")
                .setView(input)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("CREATE", (dialog, which) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) {
                        status.setText("Enter a profile name first.");
                        return;
                    }
                    try {
                        addProfile(InstanceProfile.vanilla(name, "1.21.1"));
                        status.setText("Profile created: " + name);
                    } catch (IllegalArgumentException ex) {
                        status.setText(ex.getMessage());
                    }
                })
                .show();
    }

    private void addProfile(InstanceProfile profile) {
        instances.add(profile);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackgroundColor(panel);

        TextView name = new TextView(this);
        name.setText(profile.getName());
        name.setTextColor(white);
        name.setTextSize(17);
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        card.addView(name);

        TextView details = new TextView(this);
        details.setText("Minecraft " + profile.getMinecraftVersion()
                + "  •  " + profile.getLoader()
                + "  •  " + profile.getMemoryMb() + " MB");
        details.setTextColor(muted);
        details.setTextSize(12);
        details.setPadding(0, dp(5), 0, 0);
        card.addView(details);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.bottomMargin = dp(9);
        profileContainer.addView(card, params);
    }

    private Button makeButton(String text, int color, int textColor) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(textColor);
        button.setTextSize(14);
        button.setAllCaps(false);
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
        button.setGravity(Gravity.CENTER);
        button.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(50)));
        return button;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
