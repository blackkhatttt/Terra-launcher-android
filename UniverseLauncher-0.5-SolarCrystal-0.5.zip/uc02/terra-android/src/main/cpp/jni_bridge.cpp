#include <jni.h>
#include <cstdint>
#include <string>
#include <vector>

#include "solarcrystal.h"
#include "class_reader.h"
#include "vm_runtime.h"
#include "class_method_executor.h"

extern "C" JNIEXPORT jstring JNICALL
Java_com_universe_solarcrystal_NativeBridge_nativeVersion(JNIEnv* env, jclass) {
    return env->NewStringUTF(solarcrystal::version());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_universe_solarcrystal_NativeBridge_nativeStatus(JNIEnv* env, jclass) {
    const auto message = solarcrystal::status();
    return env->NewStringUTF(message.c_str());
}

extern "C" JNIEXPORT jint JNICALL
Java_com_universe_solarcrystal_NativeBridge_nativeAdd(JNIEnv*, jclass, jint a, jint b) {
    return solarcrystal::add(a, b);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_universe_solarcrystal_NativeBridge_nativeInspectClass(JNIEnv* env, jclass, jbyteArray class_bytes) {
    if (class_bytes == nullptr) {
        return env->NewStringUTF("SolarCrystal Class Reader: ERROR\nInput byte array is null");
    }

    const jsize length = env->GetArrayLength(class_bytes);
    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(length));
    if (length > 0) {
        env->GetByteArrayRegion(class_bytes, 0, length, reinterpret_cast<jbyte*>(bytes.data()));
        if (env->ExceptionCheck()) return nullptr;
    }

    const std::string result = solarcrystal::inspect_class_file(bytes.data(), bytes.size());
    return env->NewStringUTF(result.c_str());
}


extern "C" JNIEXPORT jstring JNICALL
Java_com_universe_solarcrystal_NativeBridge_nativeExecuteBytecode(
        JNIEnv* env, jclass, jbyteArray bytecode, jint max_stack, jint max_locals) {
    if (bytecode == nullptr) {
        return env->NewStringUTF("SolarCrystal VM: ERROR\nInput bytecode array is null");
    }
    if (max_stack < 0 || max_stack > 65535 || max_locals < 0 || max_locals > 65535) {
        return env->NewStringUTF("SolarCrystal VM: ERROR\nInvalid max_stack or max_locals");
    }
    const jsize length = env->GetArrayLength(bytecode);
    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(length));
    if (length > 0) {
        env->GetByteArrayRegion(bytecode, 0, length, reinterpret_cast<jbyte*>(bytes.data()));
        if (env->ExceptionCheck()) return nullptr;
    }
    const std::string result = solarcrystal::execute_bytecode(
            bytes.data(), bytes.size(), static_cast<std::uint16_t>(max_stack),
            static_cast<std::uint16_t>(max_locals));
    return env->NewStringUTF(result.c_str());
}


extern "C" JNIEXPORT jstring JNICALL
Java_com_universe_solarcrystal_NativeBridge_nativeExecuteClassMethod(
        JNIEnv* env, jclass, jbyteArray class_bytes, jstring method_name, jstring descriptor) {
    if (class_bytes == nullptr || method_name == nullptr || descriptor == nullptr) {
        return env->NewStringUTF("SolarCrystal Class VM: ERROR\nClass bytes, method name and descriptor are required");
    }
    const jsize length = env->GetArrayLength(class_bytes);
    if (length <= 0 || length > 16 * 1024 * 1024) {
        return env->NewStringUTF("SolarCrystal Class VM: ERROR\nClass file is empty or exceeds 16 MiB limit");
    }
    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(length));
    env->GetByteArrayRegion(class_bytes, 0, length, reinterpret_cast<jbyte*>(bytes.data()));
    if (env->ExceptionCheck()) return nullptr;

    const char* name_chars = env->GetStringUTFChars(method_name, nullptr);
    if (name_chars == nullptr) return nullptr;
    const std::string name(name_chars);
    env->ReleaseStringUTFChars(method_name, name_chars);

    const char* descriptor_chars = env->GetStringUTFChars(descriptor, nullptr);
    if (descriptor_chars == nullptr) return nullptr;
    const std::string method_descriptor(descriptor_chars);
    env->ReleaseStringUTFChars(descriptor, descriptor_chars);

    const std::string result = solarcrystal::execute_class_method(
            bytes.data(), bytes.size(), name, method_descriptor);
    return env->NewStringUTF(result.c_str());
}
