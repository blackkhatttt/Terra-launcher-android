#pragma once

#include <cstddef>
#include <cstdint>
#include <string>

namespace solarcrystal {

// Extracts a method's Code attribute from a JVM class file and executes it
// with SolarCrystal's currently supported integer-bytecode interpreter.
std::string execute_class_method(const std::uint8_t* data, std::size_t size,
                                 const std::string& method_name,
                                 const std::string& method_descriptor);

}
