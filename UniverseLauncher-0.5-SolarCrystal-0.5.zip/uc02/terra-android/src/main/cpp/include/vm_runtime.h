#pragma once
#include <cstddef>
#include <cstdint>
#include <string>
namespace solarcrystal {
// Executes a documented subset of JVM integer bytecode; not a complete JVM.
std::string execute_bytecode(const std::uint8_t* code, std::size_t code_size,
                             std::uint16_t max_stack, std::uint16_t max_locals);
}
