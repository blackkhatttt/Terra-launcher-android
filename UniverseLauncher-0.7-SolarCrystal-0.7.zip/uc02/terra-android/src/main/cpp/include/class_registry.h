#pragma once

#include <cstddef>
#include <cstdint>
#include <string>

namespace solarcrystal {

// Parses and registers class metadata. This is metadata loading/resolution,
// not JVM bytecode verification, class initialization, or object execution.
std::string load_class(const std::uint8_t* data, std::size_t size);
std::string resolve_class(const std::string& internal_name);
std::string resolve_method(const std::string& internal_name,
                           const std::string& method_name,
                           const std::string& descriptor);
void clear_class_registry();

} // namespace solarcrystal
