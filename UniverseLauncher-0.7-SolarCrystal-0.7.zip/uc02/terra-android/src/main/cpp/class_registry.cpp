#include "class_registry.h"

#include <jni.h>

#include <cstdint>
#include <map>
#include <mutex>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace solarcrystal {
namespace {

class Reader {
public:
    Reader(const std::uint8_t* bytes, std::size_t length)
        : data_(bytes), size_(length) {
        if (bytes_unsafe() == nullptr && length != 0)
            throw std::runtime_error("Null class-file buffer");
    }
    std::uint8_t u1() { require(1); return data_[position_++]; }
    std::uint16_t u2() {
        return static_cast<std::uint16_t>((static_cast<std::uint16_t>(u1()) << 8) | u1());
    }
    std::uint32_t u4() {
        return (static_cast<std::uint32_t>(u1()) << 24)
             | (static_cast<std::uint32_t>(u1()) << 16)
             | (static_cast<std::uint32_t>(u1()) << 8)
             | static_cast<std::uint32_t>(u1());
    }
    std::string utf8(std::uint16_t length) {
        require(length);
        std::string value(reinterpret_cast<const char*>(data_ + position_), length);
        position_ += length;
        return value;
    }
    void skip(std::size_t amount) { require(amount); position_ += amount; }
    std::size_t remaining() const { return size_ - position_; }
private:
    const std::uint8_t* data_;
    std::size_t size_;
    std::size_t position_ = 0;
    const std::uint8_t* bytes_unsafe() const { return data_; }
    void require(std::size_t amount) const {
        if (amount > size_ - position_) throw std::runtime_error("Unexpected end of .class file");
    }
};

struct CpEntry { std::uint8_t tag = 0; std::uint16_t index = 0; std::string text; };
struct Method { std::uint16_t access = 0; std::string name; std::string descriptor; };
struct ClassInfo {
    std::string name;
    std::string super_name;
    std::vector<std::string> interfaces;
    std::vector<Method> methods;
    std::uint16_t access = 0;
    std::uint16_t major = 0;
    std::uint16_t minor = 0;
};

std::map<std::string, ClassInfo> registry;
std::mutex registry_mutex;

std::string cp_utf8(const std::vector<CpEntry>& cp, std::uint16_t index) {
    if (index == 0 || index >= cp.size() || cp[index].tag != 1)
        throw std::runtime_error("Invalid CONSTANT_Utf8 index");
    return cp[index].text;
}
std::string cp_class(const std::vector<CpEntry>& cp, std::uint16_t index) {
    if (index == 0 || index >= cp.size() || cp[index].tag != 7)
        throw std::runtime_error("Invalid CONSTANT_Class index");
    return cp_utf8(cp, cp[index].index);
}
void skip_attributes(Reader& reader, std::uint16_t count) {
    for (std::uint16_t i = 0; i < count; ++i) {
        (void)reader.u2();
        const std::uint32_t length = reader.u4();
        reader.skip(length);
    }
}
ClassInfo parse_class(const std::uint8_t* data, std::size_t size) {
    if (size == 0 || size > 16u * 1024u * 1024u)
        throw std::runtime_error("Class file is empty or exceeds 16 MiB limit");
    Reader r(data, size);
    if (r.u4() != 0xCAFEBABE) throw std::runtime_error("Invalid class-file magic");
    ClassInfo info;
    info.minor = r.u2();
    info.major = r.u2();
    const std::uint16_t cp_count = r.u2();
    if (cp_count < 1) throw std::runtime_error("Invalid constant_pool_count");
    std::vector<CpEntry> cp(cp_count);
    for (std::uint32_t i = 1; i < cp_count; ++i) {
        CpEntry& e = cp[i];
        e.tag = r.u1();
        switch (e.tag) {
            case 1: e.text = r.utf8(r.u2()); break;
            case 3: case 4: r.skip(4); break;
            case 5: case 6:
                r.skip(8);
                if (i + 1 >= cp_count) throw std::runtime_error("Invalid two-slot constant");
                ++i;
                break;
            case 7: case 8: case 16: case 19: case 20: e.index = r.u2(); break;
            case 9: case 10: case 11: case 12: case 17: case 18: r.skip(4); break;
            case 15: r.skip(3); break;
            default: throw std::runtime_error("Unsupported constant-pool tag " + std::to_string(e.tag));
        }
    }
    info.access = r.u2();
    info.name = cp_class(cp, r.u2());
    const std::uint16_t super_index = r.u2();
    if (super_index != 0) info.super_name = cp_class(cp, super_index);
    const std::uint16_t interface_count = r.u2();
    for (std::uint16_t i = 0; i < interface_count; ++i)
        info.interfaces.push_back(cp_class(cp, r.u2()));
    const std::uint16_t field_count = r.u2();
    for (std::uint16_t i = 0; i < field_count; ++i) {
        r.skip(6);
        skip_attributes(r, r.u2());
    }
    const std::uint16_t method_count = r.u2();
    for (std::uint16_t i = 0; i < method_count; ++i) {
        Method m;
        m.access = r.u2();
        m.name = cp_utf8(cp, r.u2());
        m.descriptor = cp_utf8(cp, r.u2());
        skip_attributes(r, r.u2());
        info.methods.push_back(m);
    }
    skip_attributes(r, r.u2());
    if (r.remaining() != 0) throw std::runtime_error("Unexpected trailing class-file bytes");
    if (info.name.empty() || info.name[0] == '[' || info.name.find('.') != std::string::npos)
        throw std::runtime_error("Invalid internal class name");
    return info;
}

bool find_method_locked(const std::string& class_name, const std::string& method_name,
                        const std::string& descriptor, std::vector<std::string>& visited,
                        std::string& found_in, std::uint16_t& access) {
    if (class_name.empty()) return false;
    for (const auto& v : visited) if (v == class_name) return false;
    visited.push_back(class_name);
    auto it = registry.find(class_name);
    if (it == registry.end()) return false;
    for (const Method& m : it->second.methods) {
        if (m.name == method_name && m.descriptor == descriptor) {
            found_in = class_name;
            access = m.access;
            return true;
        }
    }
    for (const auto& interface_name : it->second.interfaces)
        if (find_method_locked(interface_name, method_name, descriptor, visited, found_in, access)) return true;
    return find_method_locked(it->second.super_name, method_name, descriptor, visited, found_in, access);
}

std::string access_text(std::uint16_t flags) {
    std::ostringstream out;
    if (flags & 0x0001) out << "public ";
    if (flags & 0x0010) out << "final ";
    if (flags & 0x0200) out << "interface ";
    if (flags & 0x0400) out << "abstract ";
    if (flags & 0x2000) out << "annotation ";
    if (flags & 0x4000) out << "enum ";
    std::string s = out.str();
    if (!s.empty()) s.pop_back();
    return s.empty() ? "package-private" : s;
}

jstring jresult(JNIEnv* env, const std::string& s) { return env->NewStringUTF(s.c_str()); }
std::string from_java(JNIEnv* env, jstring value) {
    const char* chars = env->GetStringUTFChars(value, nullptr);
    if (!chars) throw std::runtime_error("Could not read Java string");
    std::string result(chars);
    env->ReleaseStringUTFChars(value, chars);
    return result;
}

} // namespace

std::string load_class(const std::uint8_t* data, std::size_t size) {
    try {
        ClassInfo info = parse_class(data, size);
        std::lock_guard<std::mutex> lock(registry_mutex);
        if (registry.find(info.name) != registry.end())
            return "SolarCrystal Class Loader: ERROR\nClass already loaded: " + info.name;
        const std::string name = info.name;
        const std::string parent = info.super_name.empty() ? "<none>" : info.super_name;
        const std::size_t method_count = info.methods.size();
        const std::size_t interface_count = info.interfaces.size();
        const std::uint16_t major = info.major;
        const std::uint16_t minor = info.minor;
        registry.emplace(name, std::move(info));
        std::ostringstream out;
        out << "SolarCrystal Class Loader: OK\n"
            << "Loaded: " << name << "\n"
            << "Superclass: " << parent << "\n"
            << "Interfaces: " << interface_count << "\n"
            << "Methods registered: " << method_count << "\n"
            << "Class-file version: " << major << '.' << minor << "\n"
            << "Registry size: " << registry.size();
        return out.str();
    } catch (const std::exception& e) {
        return std::string("SolarCrystal Class Loader: ERROR\n") + e.what();
    }
}

std::string resolve_class(const std::string& name) {
    std::lock_guard<std::mutex> lock(registry_mutex);
    auto it = registry.find(name);
    if (it == registry.end()) return "SolarCrystal Class Resolver: NOT FOUND\n" + name;
    const ClassInfo& c = it->second;
    std::ostringstream out;
    out << "SolarCrystal Class Resolver: OK\n"
        << "Resolved: " << c.name << "\n"
        << "Access: " << access_text(c.access) << "\n"
        << "Superclass: " << (c.super_name.empty() ? "<none>" : c.super_name) << "\n"
        << "Superclass state: "
        << (c.super_name.empty() || c.super_name == "java/lang/Object" || registry.count(c.super_name)
            ? "available / bootstrap" : "not loaded yet") << "\n"
        << "Interfaces: " << c.interfaces.size() << "\n"
        << "Methods: " << c.methods.size();
    return out.str();
}

std::string resolve_method(const std::string& class_name, const std::string& method_name,
                           const std::string& descriptor) {
    std::lock_guard<std::mutex> lock(registry_mutex);
    if (!registry.count(class_name))
        return "SolarCrystal Method Resolver: ERROR\nClass is not loaded: " + class_name;
    std::vector<std::string> visited;
    std::string found_in;
    std::uint16_t access = 0;
    if (!find_method_locked(class_name, method_name, descriptor, visited, found_in, access)) {
        return "SolarCrystal Method Resolver: NOT FOUND\n" + class_name + "." + method_name + descriptor;
    }
    std::ostringstream out;
    out << "SolarCrystal Method Resolver: OK\n"
        << "Requested class: " << class_name << "\n"
        << "Resolved owner: " << found_in << "\n"
        << "Method: " << method_name << descriptor << "\n"
        << "Access flags: 0x" << std::hex << access << std::dec << "\n"
        << "Resolution: declared method / inherited method";
    return out.str();
}

void clear_class_registry() {
    std::lock_guard<std::mutex> lock(registry_mutex);
    registry.clear();
}

} // namespace solarcrystal

extern "C" JNIEXPORT jstring JNICALL
Java_com_universe_solarcrystal_NativeBridge_nativeLoadClass(
    JNIEnv* env, jclass, jbyteArray class_bytes) {
    if (!class_bytes) return solarcrystal::jresult(env, "SolarCrystal Class Loader: ERROR\nInput is null");
    const jsize n = env->GetArrayLength(class_bytes);
    if (n <= 0 || n > 16 * 1024 * 1024)
        return solarcrystal::jresult(env, "SolarCrystal Class Loader: ERROR\nInvalid class size");
    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(n));
    env->GetByteArrayRegion(class_bytes, 0, n, reinterpret_cast<jbyte*>(bytes.data()));
    if (env->ExceptionCheck()) return nullptr;
    return solarcrystal::jresult(env, solarcrystal::load_class(bytes.data(), bytes.size()));
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_universe_solarcrystal_NativeBridge_nativeResolveClass(
    JNIEnv* env, jclass, jstring class_name) {
    if (!class_name) return solarcrystal::jresult(env, "SolarCrystal Class Resolver: ERROR\nClass name is null");
    try { return solarcrystal::jresult(env, solarcrystal::resolve_class(solarcrystal::from_java(env, class_name))); }
    catch (const std::exception& e) { return solarcrystal::jresult(env, std::string("ERROR\n") + e.what()); }
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_universe_solarcrystal_NativeBridge_nativeResolveMethod(
    JNIEnv* env, jclass, jstring class_name, jstring method_name, jstring descriptor) {
    if (!class_name || !method_name || !descriptor)
        return solarcrystal::jresult(env, "SolarCrystal Method Resolver: ERROR\nMissing argument");
    try {
        return solarcrystal::jresult(env, solarcrystal::resolve_method(
            solarcrystal::from_java(env, class_name), solarcrystal::from_java(env, method_name), solarcrystal::from_java(env, descriptor)));
    } catch (const std::exception& e) {
        return solarcrystal::jresult(env, std::string("ERROR\n") + e.what());
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_universe_solarcrystal_NativeBridge_nativeClearClassRegistry(JNIEnv*, jclass) {
    solarcrystal::clear_class_registry();
}
