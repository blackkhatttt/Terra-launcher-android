package com.universe.solarcrystal;

public final class NativeBridge {

    private NativeBridge() {
    }

    static {
        System.loadLibrary("solarcrystal");
    }

    public static native String nativeVersion();

    public static native String nativeStatus();

    public static native int nativeAdd(int a, int b);

    /** Loads class metadata into SolarCrystal's in-memory class registry. */
    public static native String nativeLoadClass(byte[] classBytes);

    /** Resolves a class previously loaded into the registry. */
    public static native String nativeResolveClass(String internalName);

    /** Resolves a method by walking the loaded class, interfaces and parents. */
    public static native String nativeResolveMethod(
        String internalName,
        String methodName,
        String descriptor
    );

    /** Clears the in-memory metadata registry. */
    public static native void nativeClearClassRegistry();

    /**
     * Reads the structure of a JVM class file.
     */
    public static native String nativeInspectClass(
        byte[] classBytes
    );

    /**
     * Executes a supported subset of JVM bytecode.
     */
    public static native String nativeExecuteBytecode(
        byte[] code,
        int maxStack,
        int maxLocals
    );

    /**
     * Executes a static integer method without arguments.
     */
    public static native String nativeExecuteClassMethod(
        byte[] classBytes,
        String methodName,
        String descriptor
    );

    /**
     * Executes a static integer method with integer arguments.
     */
    public static native String nativeExecuteClassMethodWithArgs(
        byte[] classBytes,
        String methodName,
        String descriptor,
        int[] arguments
    );
}
