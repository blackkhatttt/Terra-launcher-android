# Universe Launcher 0.7 — SolarCrystal 0.7

Universe Launcher is an Android Minecraft Java launcher project. SolarCrystal is its independently developed Java class execution engine.

## SolarCrystal 0.7

Version 0.7 adds an in-memory class metadata registry, class loading, class resolution, and method resolution across registered classes, superclasses, and interfaces. It preserves the 0.6 bytecode and class-method execution tests.

This milestone does **not** implement full JVM verification, class initialization, object creation, or complete Java/Minecraft compatibility. The first Minecraft Java execution attempt remains planned for version 0.8.

## Build

Open the project root in Android Studio or run `gradle :terra-android:assembleDebug` with Java 17, Android SDK 35, NDK 26.1.10909125, and CMake 3.22.1.
