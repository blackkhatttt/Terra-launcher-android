package com.terra.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.terra.core.InstanceManager;
import com.terra.core.InstanceProfile;
import com.terra.core.TerraCore;

public class MainActivity extends Activity {
    private final InstanceManager instances = new InstanceManager();
    private LinearLayout profileContainer;
    private TextView status;

    private final int background = Color.rgb(14, 22, 18);
    private final int panel = Color.rgb(26, 40, 32);
    private final int green = Color.rgb(55, 190, 119);
    private final int white = Color.rgb(240, 247, 242);
    private final int muted = Color.rgb(171, 190, 178);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildInterface();
        addProfile(InstanceProfile.vanilla("My Minecraft", "1.21.1"));
    }

    private void buildInterface() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(background);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(34), dp(22), dp(28));
        scroll.addView(page);

        TextView logo = new TextView(this);
        logo.setText("TERRA");
        logo.setTextColor(green);
        logo.setTextSize(34);
        logo.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        page.addView(logo);

        TextView subtitle = new TextView(this);
        subtitle.setText("LAUNCHER  •  ANDROID EDITION");
        subtitle.setTextColor(muted);
        subtitle.setTextSize(12);
        subtitle.setPadding(0, 0, 0, dp(24));
        page.addView(subtitle);

        TextView heading = new TextView(this);
        heading.setText("YOUR INSTANCES");
        heading.setTextColor(white);
        heading.setTextSize(16);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        page.addView(heading);

        profileContainer = new LinearLayout(this);
        profileContainer.setOrientation(LinearLayout.VERTICAL);
        profileContainer.setPadding(0, dp(12), 0, dp(12));
        page.addView(profileContainer);

        Button create = makeButton("+  CREATE PROFILE", green, Color.BLACK);
        create.setOnClickListener(v -> showCreateDialog());
        page.addView(create);

        Button play = makeButton("PLAY", Color.rgb(24, 132, 79), Color.WHITE);
        LinearLayout.LayoutParams playParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(56));
        playParams.topMargin = dp(14);
        page.addView(play, playParams);
        play.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Terra Runtime")
                .setMessage("Minecraft Java execution is not included in this first Android prototype. The launcher interface and profile system are ready for the next development milestone.")
                .setPositiveButton("OK", null)
                .show());

        status = new TextView(this);
        status.setText(TerraCore.welcomeMessage());
        status.setTextColor(muted);
        status.setTextSize(12);
        status.setPadding(0, dp(20), 0, 0);
        page.addView(status);

        setContentView(scroll);
    }

    private void showCreateDialog() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Profile name");

        new AlertDialog.Builder(this)
                .setTitle("New Minecraft profile")
                .setView(input)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("CREATE", (dialog, which) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) {
                        status.setText("Enter a profile name first.");
                        return;
                    }
                    try {
                        addProfile(InstanceProfile.vanilla(name, "1.21.1"));
                        status.setText("Profile created: " + name);
                    } catch (IllegalArgumentException ex) {
                        status.setText(ex.getMessage());
                    }
                })
                .show();
    }

    private void addProfile(InstanceProfile profile) {
        instances.add(profile);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackgroundColor(panel);

        TextView name = new TextView(this);
        name.setText(profile.getName());
        name.setTextColor(white);
        name.setTextSize(17);
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        card.addView(name);

        TextView details = new TextView(this);
        details.setText("Minecraft " + profile.getMinecraftVersion()
                + "  •  " + profile.getLoader()
                + "  •  " + profile.getMemoryMb() + " MB");
        details.setTextColor(muted);
        details.setTextSize(12);
        details.setPadding(0, dp(5), 0, 0);
        card.addView(details);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.bottomMargin = dp(9);
        profileContainer.addView(card, params);
    }

    private Button makeButton(String text, int color, int textColor) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(textColor);
        button.setTextSize(14);
        button.setAllCaps(false);
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
        button.setGravity(Gravity.CENTER);
        button.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(50)));
        return button;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
