package com.universe.solarcrystal;

public final class Main {
    public static void main(String[] args) {
        System.out.println("=== SOLARCRYSTAL 0.1 ===");
        System.out.println("Native version: " + NativeBridge.nativeVersion());
        System.out.println("Status: " + NativeBridge.nativeStatus());
        System.out.println("JNI test: 20 + 22 = " + NativeBridge.nativeAdd(20, 22));
    }
}
