package com.universe.solarcrystal;

public final class NativeBridge {
    private NativeBridge() {}

    static {
        System.loadLibrary("solarcrystal");
    }

    public static native String nativeVersion();
    public static native String nativeStatus();
    public static native int nativeAdd(int a, int b);
}
