# SolarCrystal 0.1

SolarCrystal is an experimental C++ + Java foundation for Universe Launcher.
This starter proves the native/Java bridge; it does **not** yet run Minecraft.

## Requirements
- CMake 3.20+
- C++17 compiler
- JDK 17+
- Gradle 8+ (for the Java demo)

## Build the native core (desktop)
```bash
cmake -S . -B build -DSOLARCRYSTAL_BUILD_JNI=OFF
cmake --build build
```

## Build the Java demo
```bash
gradle -p java build
```
The Java demo expects the native library to be built and available as `libsolarcrystal` (Linux),
`solarcrystal.dll` (Windows), or `libsolarcrystal.dylib` (macOS). Set `java.library.path`
to the directory containing it.

## Android
The `android/` folder contains the Android app skeleton. Open it in Android Studio.
It uses CMake and JNI through the Android NDK. The Android build requires Android SDK,
NDK, and CMake installed in Android Studio.

## Roadmap
1. 0.1: native core + JNI bridge proof of concept.
2. 0.2: platform abstraction and logging.
3. 0.3: Java runtime discovery/selection (use a compatible, properly licensed runtime).
4. 0.4: graphics backend research and prototype.
5. Later: Minecraft version metadata, assets, libraries, authentication, and launch process.

## Important
Minecraft Java needs a compatible desktop Java runtime and graphics compatibility layer.
Android's built-in Java APIs alone are not a drop-in replacement for that runtime.
