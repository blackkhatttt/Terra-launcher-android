cmake_minimum_required(VERSION 3.20)
project(SolarCrystal VERSION 0.1.0 LANGUAGES CXX)

option(SOLARCRYSTAL_BUILD_JNI "Build JNI bridge when JNI is available" ON)

add_library(solarcrystal SHARED
    core/src/solarcrystal.cpp
)

target_include_directories(solarcrystal PUBLIC core/include)
target_compile_features(solarcrystal PUBLIC cxx_std_17)
target_compile_definitions(solarcrystal PRIVATE SOLARCRYSTAL_VERSION="${PROJECT_VERSION}")

if(SOLARCRYSTAL_BUILD_JNI)
    find_package(JNI QUIET)
    if(JNI_FOUND)
        target_sources(solarcrystal PRIVATE core/src/jni_bridge.cpp)
        target_include_directories(solarcrystal PRIVATE ${JNI_INCLUDE_DIRS})
        target_link_libraries(solarcrystal PRIVATE ${JNI_LIBRARIES})
    else()
        message(STATUS "JNI not found; building native core only.")
    endif()
endif()
