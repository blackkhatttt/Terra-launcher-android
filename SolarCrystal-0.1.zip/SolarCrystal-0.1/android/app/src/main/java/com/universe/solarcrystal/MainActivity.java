package com.universe.solarcrystal;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(32, 32, 32, 32);
        layout.setBackgroundColor(Color.rgb(12, 16, 34));

        TextView title = new TextView(this);
        title.setText("☀ SOLARCRYSTAL 0.1");
        title.setTextColor(Color.WHITE);
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);

        TextView info = new TextView(this);
        info.setTextColor(Color.rgb(190, 205, 235));
        info.setTextSize(16);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, 28, 0, 0);

        try {
            info.setText("Native core: " + NativeBridge.nativeVersion()
                    + "\n" + NativeBridge.nativeStatus()
                    + "\nJNI test: 20 + 22 = " + NativeBridge.nativeAdd(20, 22)
                    + "\n\nEngine foundation initialized.");
        } catch (UnsatisfiedLinkError error) {
            info.setText("Native library could not load. Check the NDK/CMake build.");
        }

        layout.addView(title);
        layout.addView(info);
        setContentView(layout);
    }
}
