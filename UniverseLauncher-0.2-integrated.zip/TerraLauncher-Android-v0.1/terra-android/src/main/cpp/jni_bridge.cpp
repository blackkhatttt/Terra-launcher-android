#include <jni.h>
#include "solarcrystal.h"

extern "C" JNIEXPORT jstring JNICALL
Java_com_universe_solarcrystal_NativeBridge_nativeVersion(JNIEnv* env, jclass) {
    return env->NewStringUTF(solarcrystal::version());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_universe_solarcrystal_NativeBridge_nativeStatus(JNIEnv* env, jclass) {
    const auto message = solarcrystal::status();
    return env->NewStringUTF(message.c_str());
}

extern "C" JNIEXPORT jint JNICALL
Java_com_universe_solarcrystal_NativeBridge_nativeAdd(JNIEnv*, jclass, jint a, jint b) {
    return solarcrystal::add(a, b);
}
