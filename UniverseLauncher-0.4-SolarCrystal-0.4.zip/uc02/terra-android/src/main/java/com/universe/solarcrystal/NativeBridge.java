package com.universe.solarcrystal;

public final class NativeBridge {
    private NativeBridge() {}
    static { System.loadLibrary("solarcrystal"); }

    public static native String nativeVersion();
    public static native String nativeStatus();
    public static native int nativeAdd(int a, int b);

    /** Parses the structure of a JVM .class file. This does not execute its bytecode. */
    public static native String nativeInspectClass(byte[] classBytes);

    /** Executes a supported subset of JVM bytecode; this is not a complete JVM. */
    public static native String nativeExecuteBytecode(byte[] code, int maxStack, int maxLocals);
}
